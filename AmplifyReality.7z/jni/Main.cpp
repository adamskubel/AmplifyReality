#include "positioning/QRFinder.hpp"
#include "LogDefinitions.h"
#include "opencv2/highgui/highgui.hpp"
#include "android_native_app_glue.h"
#include "display/NativeWindowRenderer.hpp"
#include "datacollection/ImageCollector.hpp"
#include "display/opengl/OpenGLRenderer.hpp"

using namespace std;
using namespace cv;

enum DrawMode
{
	Color = 0, Gray = 1, Binary = 2
};

int height = 480, width = 800;
int screenWidth = 960,screenHeight = 540;
DrawMode currentDrawMode = Color;

Mat * rgbImage, *binaryImage, *grayImage;
ImageCollector * imageCollector;
struct timespec lastFrame;

struct engine
{
	struct android_app* app;
	int animating;
	OpenGLRenderer glRender;
};

void process_frame(struct engine* engine)
{
	LOGD("Frame Start");
	struct timespec start, end;

	imageCollector->newFrame();
	if (currentDrawMode == Gray || currentDrawMode == Binary)
	{
		imageCollector->getImage(&grayImage, ImageCollector::GRAY);
	} else
	{
		SET_TIME(&start);
		imageCollector->getImage(&rgbImage, ImageCollector::RGBA);
		SET_TIME(&end);
		LOG_TIME("RGBA get", start, end);
	}

	SET_TIME(&start);
	imageCollector->getImage(&binaryImage, ImageCollector::OTSU);
	SET_TIME(&end);
	LOG_TIME("Binary get", start, end);

	vector<Point_<int>*> v;
	vector<Point3i> vDebug;

	SET_TIME(&start);
	QRFinder::locateQRCode(*binaryImage, v, vDebug);
	SET_TIME(&end);
	LOG_TIME("QR Search", start, end);

	if (currentDrawMode == Gray)
	{
		SET_TIME(&start)
		cvtColor(*grayImage, *rgbImage, CV_GRAY2RGBA, 4);
		SET_TIME(&end);
		LOG_TIME("Gray->RGBA", start, end);
	} else if (currentDrawMode == Binary)
	{
		SET_TIME(&start)
		cvtColor(*binaryImage, *rgbImage, CV_GRAY2RGBA, 4);
		SET_TIME(&end);
		LOG_TIME("Binary->RGBA", start, end);
	}

	for (size_t i = 0; i < v.size(); i++)
	{
		fillConvexPoly(*rgbImage, v[i], 4, Scalar(0, 0, 255, 255));
	}
	while (!v.empty())
	{
		delete v.back();
		v.pop_back();
	}
	for (size_t i = 0; i < vDebug.size(); i++)
	{
		circle(*rgbImage, Point2i((vDebug)[i].x, (vDebug)[i].y), (vDebug)[i].z, Scalar(255, 0, 0, 255), 1);
	}

	SET_TIME(&start);
	engine->glRender.render(screenWidth,screenHeight,width,height,rgbImage->ptr<uint32_t>(0));
	SET_TIME(&end);
	LOG_TIME("OpenGL Drawing",start,end);
	//NativeWindowRenderer::drawToBuffer(buffer, rgbImage);
}

void init_objects()
{
	//Mat myuv(height + height / 2, width, CV_8UC1);
	imageCollector = new ImageCollector(width, height);
}

static void engine_draw_frame(struct engine* engine)
{
	if (engine->app->window == NULL)
	{
		return;
	}

//	LOGD("Configuring window");
//	ANativeWindow_setBuffersGeometry(engine->app->window, 0, 0, WINDOW_FORMAT_RGBA_8888);
//
//	ANativeWindow_Buffer buffer;
//
//	LOGD("Locking window");
//	if (ANativeWindow_lock(engine->app->window, &buffer, NULL) < 0)
//	{
//		LOGW("Unable to lock window buffer");
//		return;
//	}

	process_frame(engine);

//	ANativeWindow_unlockAndPost(engine->app->window);

	char myTimeString[100];
	struct timespec now;
	clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &now);
	sprintf(myTimeString, "Frame took %ld ms", calc_time(lastFrame,now));
	LOGT(myTimeString);

	clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &lastFrame);
}

void engine_term_display(struct engine* engine)
{
	engine->animating = 0;
	engine->glRender.teardownOpenGL();
	imageCollector->teardown();
}

static void engine_handle_cmd(struct android_app* app, int32_t cmd)
{
	struct engine* engine = (struct engine*) app->userData;
	switch (cmd)
	{
	case APP_CMD_INIT_WINDOW:
		if (engine->app->window != NULL)
		{
			LOGD("Importing OpenGL");
			engine->glRender.initOpenGL(engine->app->window);
			LOGD("Import complete");
			engine->animating = 1;
		}
		break;
	case APP_CMD_TERM_WINDOW:
		engine_term_display(engine);
		break;
	case APP_CMD_LOST_FOCUS:
		engine->animating = 0;
		break;
	}
}

static int32_t engine_handle_input(struct android_app* app, AInputEvent* event)
{
	struct engine* engine = (struct engine*) app->userData;
	if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_MOTION)
	{
		engine->animating = 1;
		currentDrawMode = (DrawMode) ((currentDrawMode + 1) % 3);
		return 1;
	} else if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_KEY)
	{
		LOGI("Key event: action=%d keyCode=%d metaState=0x%x", AKeyEvent_getAction(event), AKeyEvent_getKeyCode(event), AKeyEvent_getMetaState(event));
	}

	return 0;
}

void android_main(struct android_app* state)
{
	static int init;
	struct engine engine;

	app_dummy();

	memset(&engine, 0, sizeof(engine));
	state->userData = &engine;
	state->onAppCmd = engine_handle_cmd;
	state->onInputEvent = engine_handle_input;
	engine.app = state;
	engine.animating = 0;

	//if (!init)
	{
		init_objects();
		init = 1;
	}

	while (1)
	{

		// Read all pending events.
		int ident;
		int events;
		struct android_poll_source* source;

		// If not animating, we will block forever waiting for events.
		// If animating, we loop until all events are read, then continue
		// to draw the next frame of animation.
		struct timespec start, end;
		SET_TIME(&start);
		while ((ident = ALooper_pollAll(engine.animating ? 0 : -1, NULL, &events, (void**) &source)) >= 0)
		{

			// Process this event.
			if (source != NULL)
			{
				source->process(state, source);
			}

			// Check if we are exiting.
			if (state->destroyRequested != 0)
			{
				LOGI("Engine thread destroy requested!");
				engine_term_display(&engine);
				return;
			}
		}

		SET_TIME(&end);
		LOG_TIME("Event Loop", start, end);

		if (engine.animating)
		{
;
//			engine.glRender.render(width, height);
//			LOGD("Render complete");
			engine_draw_frame(&engine);
		}
	}

	engine.glRender.teardownOpenGL();

}

