#include "QRFinder.hpp"
#include "LogDefinitions.h"
#include "opencv2/highgui/highgui.hpp"
#include "android_native_app_glue.h"



struct timespec start;


