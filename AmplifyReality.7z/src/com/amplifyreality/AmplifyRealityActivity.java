package com.amplifyreality;

import android.app.NativeActivity;

public class AmplifyRealityActivity extends NativeActivity {
}