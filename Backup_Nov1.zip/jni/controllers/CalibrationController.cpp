#include "CalibrationController.hpp"

CalibrationController::CalibrationController()
{
	objectPoints = new vector<vector<Point3f> >();
	imagePoints = new vector<vector<Point2f> >();
	collectionCount = 0;
	calibrationComplete = false;


	rgbImage = new Mat(1, 1, CV_8UC4);

}

CalibrationController::~CalibrationController()
{
	delete objectPoints;
	delete imagePoints;
}

bool CalibrationController::isDone()
{
	return calibrationComplete;
}

vector<Point3f> CalibrationController::generateChessboardPoints(int w, int h, float squareSize)
{
	vector<Point3f> points;

	for (int x = 0; x < w; x++)
	{
		for (int y = 0; y < h; y++)
		{
			Point3f point(squareSize * ((float) x), squareSize * ((float) y), 0);
			points.push_back(point);
		}
	}
	return points;
}

void CalibrationController::findCorners(struct engine* engine)
{
	LOGD("Find corners Start");
	struct timespec start, end;

	engine->imageCollector->newFrame();
	engine->imageCollector->getImage(&grayImage, ImageCollector::GRAY);

	SET_TIME(&start);
	engine->imageCollector->getImage(&binaryImage, ImageCollector::OTSU);
	SET_TIME(&end);
	LOG_TIME("Binary get", start, end);

	Size_<int> chessBoardSize(7, 7);

	vector<Point2f> corners;
	LOGD("Finding corners");
	bool wasFound = findChessboardCorners(*grayImage, chessBoardSize, corners, CALIB_CB_FAST_CHECK);
	if (wasFound)
		LOGD("Corners were found, num=%d", corners.size());
	else
		LOGD("No corners found");

	SET_TIME(&start)
	cvtColor(*grayImage, *rgbImage, CV_GRAY2RGBA, 4);
	SET_TIME(&end);
	LOG_TIME("Gray->RGBA", start, end);

	LOGD("Drawing corners");
	drawChessboardCorners(*rgbImage, chessBoardSize, corners, wasFound);

	if (wasFound)
	{

		objectPoints->push_back(generateChessboardPoints(7, 7, 25.0f));
		imagePoints->push_back(corners);
		collectionCount++;
	}

	if (collectionCount >= SampleCount)
	{
		LOGD("Calculate camera matrix");
		SET_TIME(&start);

		Mat cameraMatrix;
		cameraMatrix = Mat::zeros(3, 3, CV_64F);
		Mat distortionMatrix;
		vector<Mat> rotations, translations;
		calibrateCamera(*objectPoints, *imagePoints, grayImage->size(), cameraMatrix, distortionMatrix, rotations, translations, 0);
		SET_TIME(&end);
		LOG_TIME("Camera Matrix Generation", start, end);
		LOGI(
				"Camera matrix: [%lf,%lf,%lf;%lf,%lf,%lf;%lf,%lf,%lf]", cameraMatrix.at<double>(0,0), cameraMatrix.at<double>(0,1), cameraMatrix.at<double>(0,2), cameraMatrix.at<double>(1,0), cameraMatrix.at<double>(1,1),
				cameraMatrix.at<double>(1,2), cameraMatrix.at<double>(2,0), cameraMatrix.at<double>(2,1), cameraMatrix.at<double>(2,2));

		calibrationComplete = true;
	}

	SET_TIME(&start);
	engine->glRender.render(engine->screenWidth, engine->screenHeight, engine->imageWidth, engine->imageHeight, rgbImage->ptr<uint32_t>(0));
	SET_TIME(&end);
	LOG_TIME("OpenGL Drawing", start, end);
}
